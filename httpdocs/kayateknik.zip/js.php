<!-- JavaScript Bundle -->
	<script src="js/jquery.bundle.js"></script>
	<!-- Theme Script init() -->
	<script src="js/script.js"></script>
	<!-- End script -->
	
	 <style type="text/css">div.fixpo{width:200px;height:160px;position:fixed;z-index:4000;} div.koddostu-po{bottom:0px;left:0px;}</style>
 <style type="text/css">div.fixpo{_position:absolute;}div.koddostu-po{_bottom:auto;_top:expression(ie6=(document.documentElement.scrollTop+document.documentElement.clientHeight - 52+"px") );}</style>
<div class="fixpo koddostu-po"><a href="tel:<?php echo $ayarlar["strPhone"]; ?>" target="_blank" onfocus="this.blur();" id="koddostu_iletisim" class="kod_dostu_iletisim kutusu"></a></div>

<style>#koddostu_iletisim{position:absolute;  top: 49px;    left: 9px;display:block;width:200px;height:160px;background:transparent url(https://www.gaziantepkayateknikservis.com/telefon.png) no-repeat top left;}</style>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-WC9Z917LJG"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-WC9Z917LJG');
</script>